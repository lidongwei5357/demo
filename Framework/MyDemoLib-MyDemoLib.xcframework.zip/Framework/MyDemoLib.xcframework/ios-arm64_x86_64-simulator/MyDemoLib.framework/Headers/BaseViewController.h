//

//  FYGOMS
//
//  Created by wangkun on 15/6/8.
//  Copyright (c) 2015年 feeyo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UIView+Size.h"

#import "FGUIDefine.h"


@interface BaseViewController : UIViewController
- (void)setupNavigationBar;
@end
