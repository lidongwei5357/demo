//
//  NSString+FGMD5.h
//  WGS
//
//  Created by wangkun on 2017/7/6.
//  Copyright © 2017年 wangkun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (FGMD5)
- (NSString *)md5String;
@end
